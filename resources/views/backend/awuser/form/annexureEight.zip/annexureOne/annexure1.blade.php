@inject('general', 'App\Http\Controllers\Backend\Users\AnnexureController')
@extends('layouts.masters.backend')
@section('title', 'Details of Solar PV Modules')
@section('content')

<div class="row">
    @include('backend.user.form._stepper')
    <div class="col-md-12">
        @include('layouts.partials.backend._flash')
        <div class="box box-primary">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="box-body">
                            <!-- @if ($errors->any())
                            <span class="invalid-feedback1 all_valid_class text-danger" style="display:block">*Please
                                enter all details properly. Do not use special characters.</span>
                            @endif -->
                            <form action="{{URL::to('/users/annexure-one')}}" method="POST"
                                enctype="multipart/form-data" id="formAjax">
                                @csrf
                                @method('POST')
                                <table class="table table-bordered" id="show_data"
                                    style="display:@if($annexuredata!=null)  @else none @endif">
                                    <tr>
                                        <td>
                                            <table class="table table-bordered">
                                                <tr>
                                                    <th width="20%">Module Technology</th>
                                                    <td class="text-primary">{{$annexuredata->module_name ?? ''}}</td>
                                                </tr>
                                                <tr>
                                                    <th width="15%">Representative Main Model</th>
                                                    <td class="text-primary">{{$annexuredata->main_model ?? ''}}</td>
                                                </tr>
                                                <tr>
                                                    <th>Pmax (Wp) of Main Model</th>
                                                    <td colspan="3" class="text-primary">
                                                        {{$annexuredata->pmax_model ?? ''}} Wp</td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <table class="table table-bordered1">
                                                <tr>
                                                    <th>S.No</th>
                                                    <th width="20%" class="text-center">Applicable models covered under
                                                        +- 5%, Pmax of Main Model</th>
                                                    <th class="text-center">Pmax (Wp) of Applicable Models Model</th>
                                                    <th>No of Cells & Cell Type (Full/Half/Cut)</th>
                                                    <th>System Voltage (VDC)</th>
                                                    <th></th>
                                                </tr>
                                                <tbody>
                                                    @if(!Empty($annexuredata))
                                                    @foreach($annexuredata->applicable_model_covered as $record)
                                                    <tr class="record">
                                                        <td>{{$loop->iteration}}</td>
                                                        <td class="text-center">
                                                            {{$annexuredata->applicable_model_covered[$loop->iteration-1] ?? ''}}
                                                        </td>
                                                        <td class="text-center">
                                                            {{$annexuredata->applicable_model[$loop->iteration-1] ?? ''}}
                                                            Wp</td>
                                                        <td> <input type="text" name="no_of_cells[]"
                                                                id="no_of_cells_{{$loop->iteration}}" min="0" step="any"
                                                                placeholder="Enter No of Cells & Cell Type. eg : 08 (Half) *"
                                                                value="{{ $annexuredata['annexure'][$loop->iteration-1]['no_of_cells'] ?? '' }}"
                                                                class="from-control no_of_cells"
                                                                onchange="copyCellDataTo(this)">
                                                            <i name="no_of_cells.{{$loop->iteration-1}}"></i>
                                                        </td>
                                                        <td><input type="number" name="system_voltage[]"
                                                                id="system_voltage_{{$loop->iteration}}" min="0"
                                                                step="any" placeholder="Enter System Voltage (VDC)*"
                                                                value="{{ $annexuredata['annexure'][$loop->iteration-1]['system_voltage'] ?? '' }}"
                                                                class="from-control system_voltage">
                                                            <i name="system_voltage.{{$loop->iteration-1}}"></i>
                                                            @if($loop->iteration>1)
                                                            <input type="checkbox" name="same{{$loop->iteration-1}}"
                                                                id="same{{$loop->iteration}}"
                                                                onchange="copydata({{$loop->iteration}})"
                                                                style="font-size:12px;"> <span
                                                                class="text-primary same_as_above">Autofill as filled
                                                                above</span>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                    @endforeach
                                                    @endif
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <button type="submit" name="submit" class="btn btn-success" id="submit"><i
                                                    class='bi bi-arrow-bar-up'></i> @if(isset($annexuredata->id) &&
                                                $annexuredata->id !='')Update @else Save @endif</button>
                                            <input type="hidden" name="edit_id" id="edit_id"
                                                value="@if(isset($annexuredata->id)){{$general->encodeid($annexuredata->id)}}@endif">
                                            <input type="hidden" name="application_id" id="application_id"
                                                value="{{$general->encodeid($application_id)}}">
                                            <a href="{{URL::to('users/annexure-one/'.$general->encodeid($application_id))}}"
                                                class="btn btn-danger"><i class='bi bi-x'></i> Cancel </a>
                                        </td>
                                    </tr>
                                </table>
                                <table class="table table-bordered text-center">
                                    <thead>
                                        <tr>
                                            <th>3.1 </th>
                                            <th scope="col" colspan="8" class="text-left">Solar PV Model Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">Sr.No</th>
                                            <th>Module Technology</th>
                                            <th>Representative Main Model</th>
                                            <th>Pmax (Wp) of Main Model</th>
                                            <th width="15%">Applicable models covered under +- 5%, Pmax of Main Model
                                            </th>
                                            <th width="15%">Pmax (Wp) of Applicable Models Model</th>
                                            <th width="15%">No of Cells & Cell Type (Full/Half/Third)</th>
                                            <th>System Voltage (VDC)</th>
                                            <th></th>
                                        </tr>
                                        @php $module_sheet=''; @endphp
                                        @foreach($appData as $data)
                                        @php $check=0; @endphp
                                        <tr>
                                            <th rowspan="">{{ $loop->iteration }}</th>
                                            <td>{{$data->module_name}}</td>
                                            <td>{{$data->main_model}}</td>
                                            <td class="text-center">{{$data->pmax_model}} Wp</td>
                                            <td class="text-center">
                                                <table width="100%">
                                                    @foreach ($data->applicable_model_covered as
                                                    $applicable_model_covered)
                                                    <tr>
                                                        <td style="border-bottom:1px dashed #ccc;">
                                                            {{ $applicable_model_covered }}</td>
                                                    </tr>
                                                    @endforeach
                                                </table>
                                            </td>
                                            <td class="text-center">
                                                <table width="100%">
                                                    @foreach ($data->applicable_model as $applicable_model)
                                                    <tr>
                                                        <td style="border-bottom:1px dashed #ccc;">
                                                            {{ $applicable_model }} Wp</td>
                                                    </tr>
                                                    @endforeach
                                                </table>
                                            </td>

                                            @if(!Empty($data->annexure))

                                            <td class="text-center">
                                                <table width="100%">
                                                    @foreach($data->annexure as $ann_data)
                                                    @php $check=1; $module_sheet=$ann_data->data_sheet; @endphp
                                                    <tr>
                                                        <td style="border-bottom:1px dashed #ccc;">
                                                            {{ $ann_data->no_of_cells }}</td>
                                                    </tr>
                                                    @endforeach

                                                </table>
                                            </td>
                                            <td class="text-center">
                                                <table width="100%">
                                                    @foreach($data->annexure as $ann_data2)
                                                    <tr>
                                                        <td style="border-bottom:1px dashed #ccc;">
                                                            {{ $ann_data2->system_voltage }}</td>
                                                    </tr>
                                                    @endforeach

                                                </table>
                                            </td>
                                            @endif
                                            <td><a href="{{URL::to('users/annexure-one/'.$general->encodeid($data->application_id).'/'.$general->encodeid($data->id))}}"
                                                    onClick="editAnnexureData({{$general->encodeid($data->id)}})">Edit
                                                    <i class="bi bi-pencil-square"></i></a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>

                                </table>
                            </form>

                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="{{URL::to('users/module-master/'.$general->encodeid($application_id))}}"
                                        class="btn btn-danger"><i class="bi bi-arrow-bar-left"></i>
                                        Back </a>
                                    @if($check>0)
                                    <a href="{{URL::to('users/annexure-one-b/'.$general->encodeid($application_id))}}"
                                        class="btn btn-warning">Next <i class="bi bi-arrow-bar-right"></i></a>
                                    @endif

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-6 -->
            </div>
            <!-- /.row -->
        </div>
    </div>
    <style>
    .max-char {
        position: absolute;
        right: 35px;
        margin-top: -24px;
    }
    </style>
    <script>
    function copydata(id) {
        var chk = $('#same' + id).is(":checked");
        if (chk) {
            $('#system_voltage_' + id).val($('#system_voltage_' + (id - 1)).val());
            $('#no_of_cells_' + id).val($('#no_of_cells_' + (id - 1)).val());
        } else {
            $('#system_voltage_' + id).val('');
            $('#no_of_cells_' + id).val('');
        }
    }
    </script>
    @endsection