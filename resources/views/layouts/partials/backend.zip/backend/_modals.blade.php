<!-- Modal -->
<div class="modal fade" id="uploadExcelModal" tabindex="-1" role="dialog" aria-labelledby="uploadExcelModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="uploadExcelForm" enctype="multipart/form-data">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="consumerApprovalModalLabel">Upload CSV</h4>
                </div>
                <div class="modal-body">
                    <input type="file" class="form-control" name="excel_file">
                </div>
                <div class="modal-footer">
                    <button type="submit" id="uploadSubmitButton" class="btn btn-primary">Submit</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="ExErrorModal" tabindex="-1" aria-labelledby="exErrorLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-danger">
                <h4 class="modal-title" style="color:#fff" id="exErrorLabel"></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <img src="{{asset('images/error-icon.png')}}" alt="" class="exception-error">
                <span id="exErrorMessage"></span>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="termcondition" tabindex="-1" aria-labelledby="exErrorLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h4 class="modal-title" style="color:#fff" id="exErrorLabel"> Terms and Conditions</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <span style="font-weight: 400;color: #0d0da2;font-style: italic;">I
                    do hereby
                    declare that all information and
                    documents are provided in complete manner. I confirm
                    that all the
                    information provided in the ‘Application Form’ and in
                    the other
                    documents is true, complete and correct. I agree that in
                    the event
                    of any particular information given being found false or
                    incorrect
                    or any discrepancy at any point of time, our application
                    is liable
                    to be rejected or cancelled or liable to be terminated
                    and the Solar
                    Photovoltaic (PV) Module Model shall be removed from the
                    List, if
                    enlisted, without any prior notice by MNRE. I
                    unconditionally agree
                    to comply with all the requirements, terms and
                    conditions stipulated
                    by MNRE. I also undertake to provide to MNRE, even after
                    enlistment,
                    any additional information, that is subsequently added
                    to this
                    Standard Application Format, by MNRE or any other
                    agency/
                    organisations, authorised by MNRE to do so.</span>
            </div>

        </div>
    </div>
</div>


@isset($installers)
<!-- consumer installaer association Modal -->

@endisset
@isset($inspectors)
<!-- consumer Approval Modal -->

@endisset