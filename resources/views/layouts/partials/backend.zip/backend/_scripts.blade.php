<script type="text/javascript" src="{{asset('js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.dataTables.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/dataTables.bootstrap.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.validate.min.js')}}"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script type="text/javascript" src="{{asset('js/password-validation.js')}}"></script>
<script type="text/javascript" src="{{asset('js/select2.full.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/bootstrap-datepicker.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/adminlte.min.js')}}"></script>
<script type="text/javascript" src="{{asset('sweetalert2/sweetalert2.min.js?202206071444')}}"></script>
<script type="text/javascript">
var baseUrl = '{{URL::to("/")}}';
var validator = '';
</script>
<script type="text/javascript" src="{{asset('js/common.js')}}"></script>
<script type="text/javascript" src="{{asset('js/form_custom.js')}}"></script>
<script>
$('.pdf_file').change(function() {
    var name = this.files[0].name;
    var a = (this.files[0].size);
    var fileType = this.files[0].type;
    //$("#budget_cost_details").val(this.files[0].name);
    if (a > 1000000) {
        alert('Maximum allowed size for file is "1MB" ');
        return false;
    }

    var fileExtension = ['pdf'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1 && fileType !=
        'application/pdf') {
        alert('Invalid file. Please select valid one');
        $('#' + this.id).val('').clone(true);
        return false;
    }
    if (name.match(/\./g).length > 1) {
        alert('Invalid file. Please select valid one');
        $('#' + this.id).val('').clone(true);
        return false;
    }

});
$('.img_file').change(function() {
    var name = this.files[0].name;
    var a = (this.files[0].size);
    var fileType = this.files[0].type;
    //$("#budget_cost_details").val(this.files[0].name);
    if (a > 1000000) {
        alert('Maximum allowed size for file is "1MB" ');
        return false;
    }

    var fileExtension = ['jpg', 'png', 'jpeg'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1 && fileType !=
        'application/pdf') {
        alert('Invalid Image. PNG, JPG, JPEG are allowed');
        $('#' + this.id).val('').clone(true);
        return false;
    }
    if (name.match(/\./g).length > 1) {
        alert('Invalid image. Please select valid one');
        $('#' + this.id).val('').clone(true);
        return false;
    }

});
</script>
@stack('backend-js')